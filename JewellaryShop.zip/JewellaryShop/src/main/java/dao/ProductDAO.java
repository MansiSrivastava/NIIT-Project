package dao;

import java.util.List;

import model.Product;

public interface ProductDAO {
	
	public void insert(Product p);
	public void delete(int id);
	public void update(int id,Product p);
	public Product viewById(int id);
	public List<Product> viewAllProducts();
}
