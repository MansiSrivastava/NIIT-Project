package dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import model.Product;
import model.User;

public class UserDAOImpl implements UserDAO{
	
	List<User> li=new ArrayList<User>();

	public void add(User u) {
		// TODO Auto-generated method stub
		li.add(u);
	}

	public void delete(String email) {
		// TODO Auto-generated method stub
		Iterator<User> i=li.iterator();
		while(i.hasNext()){
			User u=i.next();
			if(u.getEmail()==email){
				i.remove();
			}
		}
	}

	public void update(String email, User u) {
		// TODO Auto-generated method stub
		User tmp;
		String temail;
		for(int i=0;i<li.size();i++){
			tmp=li.get(i);
			temail=tmp.getEmail();
			if(temail==email){
				li.set(i, u);
				break;
			}
		}
	}

	public User viewByEmail(String email) {
		// TODO Auto-generated method stub
		User temp;
		String temail;
		for(int i=0;i<li.size();i++){
			temp=li.get(i);
			temail=temp.getEmail();
			if(temail==email){
				return temp;
			}
		}
		return null;
	}

	public List<User> viewAllUsers() {
		// TODO Auto-generated method stub
		return li;
	}

}
