package dao;

import java.util.List;

import model.User;

public interface UserDAO {

	public void add(User u);
	public void delete(String email);
	public void update(String email,User u);
	public User viewByEmail(String email);
	public List<User> viewAllUsers();
}
