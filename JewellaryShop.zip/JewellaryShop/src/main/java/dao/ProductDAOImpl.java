package dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import model.Product;

public class ProductDAOImpl implements ProductDAO{
	
	List<Product> li=new ArrayList<Product>();
	
	public void insert(Product p) {
		// TODO Auto-generated method stub
		li.add(p);
	}

	public void delete(int id) {
		// TODO Auto-generated method stub
		Iterator<Product> i=li.iterator();
		while(i.hasNext()){
			Product p=i.next();
			if(p.getId()==id){
				i.remove();
			}
		}
	}

	public void update(int id, Product p) {
		// TODO Auto-generated method stub
		Product temp;
		int tid;
		for(int i=0;i<li.size();i++){
			temp=li.get(i);
			tid=temp.getId();
			if(tid==id){
				li.set(i, p);
				break;
			}
		}
	}

	public Product viewById(int id) {
		// TODO Auto-generated method stub
		Product temp;
		int tid;
		for(int i=0;i<li.size();i++){
			temp=li.get(i);
			tid=temp.getId();
			if(tid==id){
				return temp;
			}
		}
		return null;
	}

	public List<Product> viewAllProducts() {
		// TODO Auto-generated method stub
		return li;
	}

}
