package com.jewellaryshop.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import model.Product;
import model.User;
import service.ProductService;
import service.UserService;

@Controller
public class HomeController
{
	@RequestMapping("/products")
    public ModelAndView dealWithProduct()
	{
		ProductService ser=new ProductService();
        Product p1=new Product();
        Product p2=new Product();
        Product p3=new Product();
        p1.setId(1);
        p1.setName("Bangles");
        p1.setDescription("Beautiful");
        p1.setCategory("Hand Wear");
        p1.setBrand("Brand1");
        p1.setPrice(500);
        ser.insertService(p1);
        p2.setId(2);
        p2.setName("Lipstick");
        p2.setDescription("Dazzling");
        p2.setCategory("Lip Wear");
        p2.setBrand("Brand2");
        p2.setPrice(50);
        ser.insertService(p2);
        p3.setId(3);
        p3.setName("Nail Paint");
        p3.setDescription("Gud");
        p3.setCategory("Nail Wear");
        p3.setBrand("Brand3");
        p3.setPrice(100);
        ser.insertService(p3);
        //ser.deleteService(3);
        List<Product> li= ser.viewAllProductsService();
        
        Gson gson = new GsonBuilder()
                .disableHtmlEscaping()
                .setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE)
                .setPrettyPrinting()
                .serializeNulls()
                .create();
        String jsonProducts=gson.toJson(li);
       
        ModelAndView model=new ModelAndView("products");
        model.addObject("lists",jsonProducts);
        return model;
    }
	
	@RequestMapping("/users")
    public ModelAndView dealWithUser()
	{
		UserService ser=new UserService();
        User u1=new User();
        User u2=new User();
        User u3=new User();
        User u4=new User();
        u1.setAge(45);
        u1.setName("User1");
        u1.setEmail("user1@gmail.com");
        u1.setPassword("pw1");
        u1.setPhoneno(9654081469L);
        ser.insertService(u1);
        u2.setAge(45);
        u2.setName("User2");
        u2.setEmail("user2@gmail.com");
        u2.setPassword("pw2");
        u2.setPhoneno(9654081469L);
        ser.insertService(u2);
        u3.setAge(45);
        u3.setName("User3");
        u3.setEmail("user3@gmail.com");
        u3.setPassword("pw3");
        u3.setPhoneno(9654081469L);
        ser.insertService(u3);
        u4.setAge(45);
        u4.setName("User4");
        u4.setEmail("user4@gmail.com");
        u4.setPassword("pw4");
        u4.setPhoneno(9654081469L);
        ser.insertService(u4);
        //ser.deleteService(3);
        List<User> li= ser.viewAllUsersService();
        //Product li=ser.viewByIdService(2);
        ModelAndView model = new ModelAndView("users");
		model.addObject("lists", li);
		return model;
    }

	@RequestMapping("/")
    public String home()
	{
        return "index";
    }
	
	@RequestMapping("/index")
    public String homepage()
	{
        return "index";
    }
	
	@RequestMapping("/aboutus")
    public String about()
	{
        return "aboutus";
    }
	
	@RequestMapping("/contactus")
    public String contact()
	{
        return "contactus";
    }
	
	@RequestMapping("/signup")
    public String signup()
	{
        return "signup";
    }
	
	@RequestMapping("/login")
    public String login()
	{
        return "login";
    }
	
	
}
