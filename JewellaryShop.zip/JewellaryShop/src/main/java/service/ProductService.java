package service;

import java.util.List;

import dao.ProductDAOImpl;
import model.Product;

public class ProductService {

	ProductDAOImpl e=new ProductDAOImpl();
	
	public void insertService(Product p){
		e.insert(p);
	}
	
	public void deleteService(int id){
		e.delete(id);
	}
	
	public void updateService(int id, Product p) {
		// TODO Auto-generated method stub
		e.update(id, p);
	}
	
	public Product viewByIdService(int id) {
		// TODO Auto-generated method stub
		Product temp = e.viewById(id);
		return temp;
	}
	
	public List<Product> viewAllProductsService(){
		List<Product> li=e.viewAllProducts();
		return li;
	}
}
