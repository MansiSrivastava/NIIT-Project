package service;

import java.util.List;

import dao.UserDAOImpl;
import model.User;

public class UserService {

UserDAOImpl e=new UserDAOImpl();
	
	public void insertService(User u){
		e.add(u);;
	}
	
	public void deleteService(String email){
		e.delete(email);
	}
	
	public void updateService(String email,User u) {
		// TODO Auto-generated method stub
		e.update(email, u);
	}
	
	public User viewByEmailService(String email) {
		// TODO Auto-generated method stub
		User temp = e.viewByEmail(email);
		return temp;
	}
	
	public List<User> viewAllUsersService(){
		List<User> li=e.viewAllUsers();
		return li;
	}
}
